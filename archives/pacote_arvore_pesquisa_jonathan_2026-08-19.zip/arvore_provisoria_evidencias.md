# Árvore provisória e quadro de evidências

## Escopo atual

Este registro foi elaborado a partir da visualização paisagem do FamilySearch associada à pessoa `GK15-TLV` e de páginas públicas consultadas em 19 de agosto de 2026. A árvore colaborativa e o resumo do MyHeritage são tratados como **fontes derivadas**. Nenhum elo abaixo foi elevado a confirmado sem certidão, registro paroquial, imagem de arquivo ou conjunto independente de evidências.

## Árvore de trabalho

```text
Jonathan Robert Silveira De Souza (GK15-TLV; 2001–vivo)
├── Valdeci Kenes de Souza (P4KK-B9S; vivo)
│   └── cônjuge: Ana Paula (P42Q-ZRT; viva)
│       └── pais exibidos na árvore: Rosalvino Schell de Souza + Carolina Augusta Kenes de Souza
│
├── avô: Rosalvino Schell de Souza (P4KK-1QH; 06/10/1940, Tapes–17/10/2014, Guaíba)
│   └── cônjuge: Carolina Augusta Kenes de Souza (P42Q-FT6; viva)
│
├── geração anterior exibida no ramo de Rosalvino:
│   ├── Raimundo José de Souza (GV4D-D91; 1914–1983)
│   │   └── cônjuge: Alicia Schell de Souza (GV54-K3Q; falecida)
│   │       └── casamento indicado: Cerro Grande, Tapes, Rio Grande do Sul
│   └── Flauliano Brasil Kenes (P7NS-NVL; 1923–2001)
│       └── cônjuge: Eva Silveira (PH4B-XS2; 1927–falecida)
│           └── casamento indicado: 28/07/1948, Capela Velha, Camaquã, Rio Grande do Sul
│
├── geração anterior exibida no mesmo painel:
│   ├── Manoel José de Souza (GV4D-FLS; 1879–1941)
│   │   └── cônjuge: Maria Candida Tavares (GV46-7JK; 1895–1956)
│   ├── Alvino Paulino de Souza (LZGD-TYJ; árvore: 1891–1977; APERS: 23/02/1897)
│   │   └── cônjuge: Rosalina Schell / Rosalina de Souza (LXVC-28B; árvore: 1899–1993; APERS: 16/12/1906)
│   │       └── casamento confirmado: 17/04/1955, Vila Cerro Grande, 3º distrito de Tapes, Rio Grande do Sul
│   ├── Manoel Geraldo Kenes (PMXJ-2SR; 1904–falecido)
│   │   └── cônjuge: Dorvalina Ferreira Kenes (G56B-32T; 1905–1939)
│   └── Antonio Manoel Silveira (PH4B-JD1; 1897–falecido)
│       └── cônjuge: Tomazia Silveira (PH4B-ZRX; 1898–falecida)
```

A disposição acima reproduz os cartões visíveis, mas a captura textual não deixou totalmente explícito qual casal é pai de cada pessoa na geração anterior. A filiação exata deve ser confirmada abrindo os perfis ou encontrando registros de nascimento, casamento e óbito. Em especial, não se deve presumir que todos os quatro casais estejam ligados à mesma linha direta sem validar a estrutura do painel.

## Quadro de evidências

| Afirmação | Fonte atual | Qualidade | Confiança atual | Próxima validação |
|---|---|---|---|---|
| Rosalvino nasceu em 06/10/1940 em Tapes | Painel da árvore FamilySearch, `P4KK-1QH`; fontes civis associadas não correspondem diretamente ao nascimento | Perfil ainda mostra `Birth • 0 Sources` | Possível | Registro civil de Tapes ou batismo |
| Rosalvino morreu em 17/10/2014 em Guaíba | Painel da árvore FamilySearch, `P4KK-1QH` | Derivada; óbito com 0 fontes exibidas | Possível | Registro civil de Guaíba, obituário ou sepultamento |
| Rosalvino ocupação: agricultor | Painel FamilySearch; 1 fonte não identificada | Derivada | Possível | Identificar a fonte e conferir a imagem |
| Rosalvino é associado a Raimundo José de Souza e Alicia Schell de Souza | Árvore FamilySearch, IDs `GV4D-D91` e `GV54-K3Q` | Árvore colaborativa | Possível | Registro de nascimento/casamento/óbito que informe filiação |
| Raimundo e Alicia casaram em Cerro Grande, Tapes | Perfil autenticado de Raimundo `GV4D-D91`; casamento listado em Cerro Grande, Tapes | Árvore colaborativa; fontes civis lidas até agora não são o casamento | Possível | Habilitação ou assento de casamento em Tapes/Cerro Grande do Sul |
| Alvino e Rosalina casaram em 17/04/1955 em Vila Cerro Grande/Tapes | Índice APERS e PDF do processo interno `NRO_INT_DOCUMENTO=180190`, com certidão final do matrimônio e tramitação completa | **Fonte primária; confirmado** | Localizar assento integral para livro, folha, termo e observações |
| Rosalina nasceu em 16/12/1906 em Americana/Cerro Grande; árvore indica 1899–1993 | Certidão de nascimento anexada ao processo APERS nº 180190, com filha legítima de Regino Schell; FamilySearch/MyHeritage reproduzem 1899–1993 | **Conflito; a certidão primária de 1906 é atualmente preferida** | Recuperar o assento original e investigar erro/homônima na árvore |
| Rosalina teve quatro filhas com Alvino | Resumo público do MyHeritage/Família FamilySearch | Derivada | Possível | Certidão de casamento, nascimentos das filhas e perfil de cada filha |
| Flauliano e Eva casaram em 28/07/1948 em Capela Velha, Camaquã | Cartão da árvore | Derivada | Possível | Registro civil ou paroquial de Camaquã |

## Novos achados documentais autenticados

O perfil autenticado de Rosalvino (`P4KK-1QH`) tem duas fontes civis. A fonte de 29/03/1971 identifica o óbito de José Maria Kenes de Souza, com 16 dias, nascido em 13/03/1971 em Guaíba, filho de Rosalvino e com Carolina Augusta Kenes de Souza no conjunto familiar. Isso confirma que Rosalvino e Carolina tiveram ao menos um filho, embora José Maria não apareça na lista de filhos exibida no detalhe do perfil.

O perfil autenticado de Raimundo (`GV4D-D91`) tem sete fontes. A fonte `6RM8-HCHX` de 21/02/1941 identifica Raimundo como mencionado no óbito de Manoel José de Souza, 62 anos, agricultor, falecido em Barão do Triunfo/São Jerônimo, certificado 10118. O índice também lista Jacinto José de Souza e Manoela Francisca da Silva. A imagem original não indexada do mesmo evento mostra Raimundo, Maria Candida Tonares/Tavares e outros participantes, mas o parentesco exato ainda deve ser lido no manuscrito.

A fonte `XSX8-CTNC` associada a Raimundo traz um registro problemático, com “Raymendo José, de Souza Santos”, naturalidade Paraíba e Alicia “Sebello” de Souza, mas datas e idades inconsistentes. Ela será mantida como pista de possível origem paraibana, não como prova da identidade ou do casamento de Raimundo.

## Achado documental novo

A pesquisa gratuita do APERS por `Schell` retornou a habilitação de casamento de **Alvino Paulino de Souza e Rosalina Schell**, sob o `Cartório do Registro Civil de Tapes`. A exportação CSV identificou o processo interno `NRO_INT_DOCUMENTO=180190`, cujo PDF contém 18 páginas.

O processo confirma por fonte primária que o casal foi habilitado e teve o matrimônio registrado em **17/04/1955**, em Vila Cerro Grande, 3º distrito de Tapes. A petição registra que Rosalina passaria a assinar **Rosalina Schell de Souza**.

As certidões anexas alteram substancialmente o quadro de hipóteses: Alvino nasceu em **23/02/1897**, filho de **Geremias de Souza** e **Anna Joaquina Paulino de Souza**, com avós paternos **Alexandrino de Oliveira e Souza** e **Felicia Rodrigues de Souza**, e avós maternos **Joaquim Paulino Tavares** e **Victoria Tavares**. Rosalina nasceu em **16/12/1906**, em Americana/Cerro Grande, e é filha legítima de **Regino Schell**. A mãe de Rosalina e a leitura completa dos avós Schell ainda precisam de confirmação em resolução ampliada.

O índice exibe `01/01/1955`, mas essa é uma data-padrão de ano; a certificação final no PDF confirma 17 de abril. A árvore do FamilySearch não foi alterada.

## Conflitos e cuidados

A página do MyHeritage mostra vários homônimos de Rosalina Schell. O perfil relevante para este ramo é o que aparece como `LXVC-28B`, “Rosalina de Souza, nascida Schell, 1899–1993”, casada com Alvino Paulino de Souza. Não deve ser misturado com a Rosalina Schell nascida em 1892, de nascimento Trott, associada a Theodor Schell e identificada no resumo FamilySearch como `K2VJ-JTR`.

Também foi desambiguada uma Eva Pereira da Silveira, `9XF9-YDG`, nascida em 15/02/1931, filha de Viriato José da Silveira e Florisia Pereira da Silveira, casada por volta de 1950 em Tapes com Cristiano Lopes Altmann. Ela corresponde ao resultado APERS “Christiano Altmann + Eva Pereira da Silveira” e **não** deve ser ligada à Eva Silveira da árvore Kenes, que aparece como nascida em 1927 e casada com Flauliano Brasil Kenes.

Há uma aparente tensão entre o casamento de Raimundo e Alicia descrito como “Cerro Grande, Tapes” e a nomenclatura atual de Cerro Grande do Sul. O histórico oficial do município informa que Cerro Grande foi o 3º distrito de Tapes em 1924 e só mais tarde se tornou município independente. Assim, a busca deverá considerar tanto o fundo do Cartório de Tapes quanto a paróquia ou cartório da localidade de Cerro Grande do Sul.

A idade de 55 anos atribuída a Rosalina no resumo do MyHeritage em 1955 é coerente com o ano de nascimento 1899, mas a idade pode ser arredondada ou derivada de uma árvore. Essa coerência cronológica aumenta a prioridade do casamento de 17/04/1955 como documento-alvo, mas não prova que a data esteja correta.

## Priorização documental

A primeira busca de alta utilidade passa a ser o assento original de nascimento de **Rosalina Schell**, em Americana/Cerro Grande, para esclarecer o nome da mãe e conferir a divergência entre 1906 no documento primário e 1899 na árvore. Também deve ser recuperado o assento de nascimento de Alvino para conferir os quatro avós identificados na habilitação.

A segunda busca é o registro de nascimento ou batismo de Rosalino Schell de Souza em Tapes, em 06 de outubro de 1940, que pode ligar diretamente o avô a seus pais e confirmar o relacionamento com Carolina. A terceira é o casamento de Raimundo José de Souza e Alicia Schell de Souza em Cerro Grande/Tapes, que pode esclarecer a origem do sobrenome Schell e a geração anterior. A quarta é o casamento de Flauliano Brasil Kenes e Eva Silveira, em 28 de julho de 1948, em Capela Velha, Camaquã.

Para recuar até a Europa, ainda falta uma fonte que nomeie o local de nascimento ou origem dos pais e avós. Até esse ponto, **não há evidência documental suficiente para afirmar um país europeu específico**. Os sobrenomes Schell, Kenes, Souza, Silveira e Tavares, isoladamente, não determinam nacionalidade.


## Atualização após as buscas sequenciais

| Afirmação | Resultado das buscas recentes | Nível mantido | Implicação |
|---|---|---|---|
| Rosalvino nasceu em 06/10/1940 em Tapes | APERS não encontrou Rosalvino/Schel em Tapes ou Guaíba; FamilySearch civil retornou zero para Schell, Schel e apenas Rosalvino em 1940; a faixa 1938–1942 trouxe homônimos | **Hipótese** | Não incorporar nenhum homônimo; priorizar assento civil/batismo em imagem ou pesquisa institucional gratuita |
| Raimundo e Alicia se casaram em Cerro Grande/Tapes | APERS: `Alicia Schell` zero; resultados de Alicia em Tapes eram Lícia/Acácia; FamilySearch civil e católico retornaram zero; Caixa 20 de Tapes está restrita | **Hipótese** | O casamento precisa de imagem restrita, livro paroquial não indexado ou confirmação institucional |
| Regino Schell pertence à linha de Rosalina | Certidão anexada ao APERS nº 180190 confirma Regino como pai de Rosalina; buscas APERS/FamilySearch não localizaram novo registro de Regino | **Confirmado apenas como pai no processo APERS** | A filiação anterior de Regino e sua origem permanecem abertas |
| Carlos Schell e Anna Schell são ascendentes de Regino | Nomes aparecem como avós na leitura da certidão de Rosalina, mas o papel exato e a relação com Regino não foram conferidos no assento original | **Pista documental** | Não criar filiação adicional como fato confirmado |
| A família Schell tem origem europeia específica | Nenhuma fonte consultada declarou naturalidade europeia ou imigração de Regino/Carlos/Anna; buscas web e índices não trouxeram registro utilizável | **Não demonstrado** | O sobrenome Schell é apenas pista; não afirmar Alemanha, Suíça ou outro país |

A árvore independente atualizada está em `/home/ubuntu/gedcom_pesquisa_jonathan/`, com 26 indivíduos, 10 famílias e 15 fontes. A validação encontrou zero referências desconhecidas e zero erros de sintaxe; a árvore original do FamilySearch não foi alterada.
